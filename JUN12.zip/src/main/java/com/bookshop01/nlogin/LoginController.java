package com.bookshop01.nlogin;

import java.io.IOException;
import javax.servlet.http.HttpSession;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.github.scribejava.core.model.OAuth2AccessToken;
/**
* Handles requests for the application home page.
*/
@Controller
public class LoginController {
	/* NaverLoginBO */
	private NaverLoginBO naverLoginBO;
	private String apiResult = null;
	@Autowired
	private void setNaverLoginBO(NaverLoginBO naverLoginBO) {
	this.naverLoginBO = naverLoginBO;
	}
	//로그인 페이지와 value 값을 맞춘다.
	@RequestMapping(value = "/member/loginForm.do", method = { RequestMethod.GET, RequestMethod.POST })
	public String login(Model model, HttpSession session) {
		/* 네이버 인증 URL을 생성하기 위하여 naverLoginBO의 getAuthorizationUrl 메소드 호출 */
		String naverAuthUrl = naverLoginBO.getAuthorizationUrl(session);
		
		// 생성되는 형태는 대략 아래와 같다 (참고용)
		//https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=***************&
		//redirect_uri=*************************************************************************
		System.out.println("네이버:" + naverAuthUrl);
		
		//naverAutoUrl
		model.addAttribute("urlT", naverAuthUrl);
		return "/member/loginForm";
	}

	//네이버 로그인 성공시 callback으로 이동
	// 주의사항 : NaverLoginBO.java 의 REDIRECT_URI 와 value값을 맞춰준다. ex) http://localhost:포트넘버/nlogin/callback
	@RequestMapping(value = "/callback", method = { RequestMethod.GET, RequestMethod.POST })
	public String callback(Model model, @RequestParam String code, @RequestParam String state, HttpSession session) throws IOException, ParseException {
		System.out.println("callback 접속성공 - 프로세스 진행");
		
		OAuth2AccessToken oauthToken;
		oauthToken = naverLoginBO.getAccessToken(session, code, state);
		
		//1. 로그인 사용자 정보를 읽어온다.
		apiResult = naverLoginBO.getUserProfile(oauthToken); //String형식의 json데이터
		/** apiResult json 구조
		{"resultcode":"00",
		"message":"success",
		"response":{"id":"123456789","nickname":"nick****","age":"20-29","gender":"M","email":"****@naver.com","name":"\abc123\abc123\abc123"}}
		**/

		//2. String형식인 apiResult를 json형태로 바꿈
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(apiResult);
		JSONObject jsonObj = (JSONObject) obj;
		
		//3. 데이터 파싱
		//Top레벨 단계 _response 파싱
		JSONObject response_obj = (JSONObject)jsonObj.get("response");
		//response의 nickname값 파싱
		String nickname = (String)response_obj.get("nickname");
		System.out.println("로그인 성공 : "+nickname+"님 환영합니다.");
		
		//4.파싱 닉네임 세션으로 저장
		session.setAttribute("sessionId",nickname); //세션 생성
		session.setAttribute("isLogOn", true);
		model.addAttribute("result", apiResult);
		return "redirect:main/main.do";
		}
	
	//로그아웃(레거시 테스트용)
	//다른 프로젝트와 결합시 session.invalidate();와 로그아웃 형태를 잘 살펴보고 변환하는것이 중요하므로
	//실 프로젝트에서 아래와 같은 방식으로 간단히 처리하는 경우는 거의 없다.
	@RequestMapping(value = "/logout", method = { RequestMethod.GET, RequestMethod.POST })
	public String logout(HttpSession session)throws IOException {
		System.out.println("logout 성공");
		session.invalidate();
		return "redirect:index.jsp";
		}
}